# Sorting-Visualizer
<h3> This is a sorting visualizer made with Tkinter. </h3>
<a href="https://replit.com/@VishalChoubey/Sorting-Visualizer?v=1"> Click on this link to use the visualizer </a>
<br>
<br>
Make sure you've installed tkinter in your system to use this visualizer
<br>
<h4>To install tkinter using python package manager, run the following:</h4>
<br>
pip install tk 
<br>
<br> 
Or follow the below website <br>
https://www.tutorialspoint.com/how-to-install-tkinter-in-python

<br>
<br>

The visualizer has: <br>
1) Merge Sort <br>
2) Selection Sort <br>
3) Bubble Sort <br>
4) Insertion Sort
<br>
<br>
Various colours are used to make the visualizer easily understandable.
<br>
<br>
Updates are highly appreciatable
<br>

